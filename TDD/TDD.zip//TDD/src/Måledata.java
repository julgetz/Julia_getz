
public interface  M�ledata {
	
	
	
	public String openFile();
	
	
	public String ReadFile();
	
	
	
    public boolean checkfile();
	
	

}
